import UIKit

//создадим струкуру отдельного элемента массива, для последующей легкости добаления новых полей текстовым методом
struct Car {
    
    var brand, model, type, assemblyYear, klasse, description : String
 
}
//тут выполняем условие того, что изначально в справочнике имеем сведения о 3 автомобилях
//Теоретически можно загнать это действие в метод ViewDidLoad, вызываемый после запуска готового приложения.

var allCars: [Car] = [Car(brand: "Mazda", model: "3", type: "Sedan", assemblyYear: "2009", klasse: "C", description: "Zoom-Zoom"), Car(brand: "Toyota", model: "Corolla", type: "Sedan", assemblyYear: "2003", klasse: "C", description: "Drive your Dreams"), Car(brand: "Honda", model: "Legend", type: "Sedan", assemblyYear: "2007", klasse: "E", description: "The Power of Dreams")]


print("Изначально имеем в справочнике три предзаполненных автомобиля: ")

//такой метод печати выводит данные в консоль более корректно, в отличие от простого print, поэтому пока так
for item in allCars {
    print(item)
}
print("")//отступ

//Добавим новый автомобиль в справочник
print("Добавим новый автомобиль Audi методом append от заранее подготовленной структуры: allCars.append(Car(...")

//используем существующий метод для добавления элемента в массив
allCars.append(Car(brand: "Audi", model: "A4", type: "Sedan", assemblyYear: "2002", klasse: "D", description: "Vorsprung durch Technik"))


print("В справочнике теперь стало 4 автомобиля:")
for item in allCars {
    print(item)
}
print("")//отступ

//Изменим один из автомобилей справочника будучи с известным индексом. Используя команду allCars[3] = Car(brand: BMW...

allCars[3] = Car(brand: "BMW", model: "520d", type: "Coupe", assemblyYear: "2006", klasse: "E", description: "пересели с Audi")
print("Изменим один из автомобилей справочника будучи с известным индексом. Используя команду allCars[3] = Car(brand: BMW...")

print("Последняя строка поменялась")
for item in allCars {
    print(item)
}

print("")//отступ



//Если хотим удалить элемент и справочника, будучи зная индекс элемента массива
allCars.remove(at: 2)// Команда для удаления элемента по индексу

print("Удалили из справочника один автомобиль Honda, зная наперед его индекс = 2 через команду allCars.remove(at: 2):")
print("")//отступ
for item in allCars {
    print(item)
}
print("")//отступ
print("")//отступ
print("В графическом интерфейсе можно выводить исходный справочник в некое текстовое поле. Для добавления навешать на кнопку функцию append, которая будет собирать вводимые пользователем параметры, например, из отдельных текстовых полей. Для удаления вызывать по другой кнопке функцию удаления. Для сохранения данных можно использовать UserDefaults.standard.set. Превдарительно заполнять массив можно в методе  ViewDidLoad")


